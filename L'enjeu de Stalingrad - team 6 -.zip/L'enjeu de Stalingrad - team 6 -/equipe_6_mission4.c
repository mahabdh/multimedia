#include <stdio.h>
#include <cstring> //strlen
#include <ctype.h> //toupper
#include <cstdlib>//malloc
#include<math.h>//log
#define TYPED_ALLOC(type) (type *) malloc( sizeof(type) )//allocation de la m�moire
#define IN_FILE "Equipe_6_Mission4_in.txt"//le fichier input
#define OUT_FILE "Equipe_6_Mission4_out.txt"//le fichier output
typedef struct noeud_struct {//structure de l'arbre
    float frequence;//frequence de caractere
    char c;//le caractere
    char code[200];
    struct noeud_struct *gauche;//gauche de l'arbre
    struct noeud_struct *droite;//droite de l'arbre
} noeud_arbre;
noeud_arbre *tableau[96], *letters[96];//96 c'est le nombre des lettres avec les caracteres speciaux

void codage(noeud_arbre *node, noeud_arbre **letters, char position, short level, char* code) {//fonction de codage
    int n;
    if ( node != NULL ) {
        if ((n = strlen(code)) < level) {
            if (position == 'R') {//position droite
                strcat(code, "0");//poids fort
            } else {
                if (position == 'L') {//position gauche
                    strcat(code, "1");}}//poids faible
        } else {
            if (n >= level) {
                code[n - (n - level) - 1] = 0;
                if (position == 'R') {//position droite
                    strcat(code, "0");//poids fort
                } else {if (position == 'L') {//position gauche
                        strcat(code, "1");}}}}//poids faible
        if (node->c >= ' ' && node->c <= 'z') {//l'interval de caractere
            strcpy(node->code, code);//oncatener l'encodzge
            strcpy(letters[node->c - ' ']->code, code);}//copierA
        codage(node->gauche, letters, 'L', level + 1, code);//codeage
        codage(node->droite, letters, 'R', level + 1, code);}}//codage

//le Minimum et second minimum
void TrouveMinEtComin(noeud_arbre *tableau[], float *min, int *minval, float *CoMin, int *CoMinval) {
    int i, k=0;//initialisation
    *minval = -1;//initialisation
    while (k < 96 && tableau[k] == NULL) k++;    //Ignorer tous les elements null
    *minval = k;//l'val min recoit le k
    *min = tableau[k]->frequence;//la valeur min est la frequence
    for ( i = k ; i < 96; i ++ ) {
        if ( tableau[i] != NULL && tableau[i]->frequence < *min ) {
            *min = tableau[i]->frequence;
            *minval = i;}}
k = 0;//reinitialiser le k � 0
    *CoMinval = -1;
    while ((k < 96 && tableau[k] == NULL) || (k == *minval && tableau[k] != NULL)) k++;//Ignorer les elements null
    *CoMin = tableau[k]->frequence;
    *CoMinval = k;
if (k == *minval) k ++;
    for ( i = k ; i < 96; i ++ ) {
        if ( tableau[i] != NULL && tableau[i]->frequence < *CoMin && i != *minval ) {
            *CoMin = tableau[i]->frequence;
            *CoMinval = i;}}}

//______________________________________________________________________//
int main() {
    char result[50] = "", str[200],tableauay[10],a[10];
    int Read, i, j, k, val, n,li,len,len1,minval, secondMinval;
    float min, secondMin,somme;
    int NombreChar = 0; //pour calculer la fr�quence
    FILE *in = fopen(IN_FILE, "r"); FILE *out;
        noeud_arbre *arbre;
    if ( in == NULL ) {
           out = fopen(OUT_FILE, "w+");//ouvrir output en mode lecture
           fprintf(out,"Le fichier input *Equipe_6_Mission4_in.txt* n'existe pas!!!");//msg d'erreur
           fclose(out);//fermer fichier input
           in = fopen(IN_FILE, "w");//creer le fichier input s'il n'existe pas
           fclose(in);
           return 0;}//fermer fichier output
        for (i = ' '; i <= 'z'; i++) {
            val = i - ' ';//pour commencer l'val avec 0
            tableau[val] = NULL;
            }     //initialisation de tableau (0-25) avec des valeurs null
        NombreChar = 0;//initaliser l nombre de caracteres a0
        Read = fgets(str, 200, in) != NULL;
        if (Read==0) {//fichier input vide
            out = fopen(OUT_FILE, "w+");//ouvrir output en mode lecture
           fprintf(out,"Le fichier input *Equipe_6_Mission4_in.txt* est vide!!!");//msg d'erreur
           fclose(out);//fermer le fichier out

        }
        while(!feof(in) || Read) {
            n = strlen(str);//nombre de caracteres dans le fichier
            for (i = 0; i < n ; i ++ ) {
               // str[i] = toupper(str[i]);//convertir tt ls caracteres en majuscules
                if (str[i] >= ' ' && str[i] <= 'z') {//calculer que les caracteres pas de num
                    NombreChar ++;//incrementer le nombre de caracteres
                    val = str[i] - ' ';//A
                    if (tableau[val] == NULL) {//si n'est pas deja trait�
                        tableau[val] = TYPED_ALLOC(noeud_arbre);// malloc(sizeof(noeud_arbre));
                        tableau[val]->c = str[i];//pointer au v=caracteres
                        tableau[val]->frequence = 1;//nombre frequence
                        tableau[val]->gauche = tableau[val]->droite = NULL;
                    } else {
                        tableau[val]->frequence += 1;}}}//deja trait� alors incrementer la frequence de 1
            if (Read) {Read = fgets(str, 200, in) != NULL;}}
    fclose(in);//fermer le fichier input
    for ( i = 0, n = 0 ; i < 96 ; i ++ ) {
        letters[i] = tableau[i];
        if (tableau[i] != NULL) {
            tableau[i]->frequence /= NombreChar;    // Calculer la fr�quence
            n ++;
            li=floor((-(log2(tableau[i]->frequence))) + 0.5); //fct floor pour retourner la valeur entiere et on calcule longeur ideal
           somme=somme+(li*tableau[i]->frequence);//somme moyenne
        }}
    j = 1;
    do {
        TrouveMinEtComin(tableau, &min, &minval, &secondMin, &secondMinval);
        if (minval != -1 && secondMinval != -1 && minval != secondMinval) {
            noeud_arbre *temp;//cr�e un noeud
            arbre = TYPED_ALLOC(noeud_arbre);// malloc(sizeof(noeud_arbre));
            arbre->frequence = tableau[minval]->frequence + tableau[secondMinval]->frequence;
            arbre->c = j;
            arbre->gauche = tableau[minval];//noued a gauche contient le minimum
            temp = TYPED_ALLOC(noeud_arbre);// malloc(sizeof(noeud_arbre));
            temp->c = tableau[secondMinval]->c;
            temp->frequence = tableau[secondMinval]->frequence;
            temp->gauche = tableau[secondMinval]->gauche;
            temp->droite = tableau[secondMinval]->droite;
            arbre->droite = temp;//noeud droit contient le secondminimum
            tableau[minval] = arbre;
            tableau[secondMinval] = NULL;}//pointer de position du tableau du second minimum sur NULL.
        j ++;
    } while( j < n );
    for ( i = 0 ; i < 96 ; i ++ ) {//parcourir le tableau jusque rencontr� le seul elemen non null
        if (tableau[i] != NULL)  {
            char code[200];
            strcpy(code, "");
            codage(arbre = tableau[i], letters, 0, 0, code);//construire le codage
            puts("\ncodage avec succes");
            break;
        }}
    in = fopen(IN_FILE, "r");
    out = fopen(OUT_FILE, "w+"); //pour �crasser le contenu pr�cident
    Read = fgets(str, 200, in) != NULL;
    //____________________________________________________________________________________
  	//pour supprimer les doublons
    for(len=0; str[len]!='\0'; len++);
    len1=0;
    for(i=0; i<(len-len1);)
    {
        if(str[i]==str[i+1])
        {
            for(j=i;j<(len-len1);j++)
                str[j]=str[j+1];
            len1++;
        }
        else
        {i++;}}
snprintf(tableauay, sizeof(tableauay), "%f", somme);//float a cst cha
fputs(tableauay,out);
    while(!feof(in) || Read) {
        n = strlen(str);
        for (i = 0; i < n ; i ++ ) {
                 snprintf(a, sizeof(a), "\n%c", str[i]);
                fputs(a,out);
                fputs(" ",out);
              if (str[i] >= ' ' && str[i] <= 'z' ) {
                val = str[i] - ' ';
                fputs(letters[val]->code, out);
            }}
        if (Read) {
            Read = fgets(str, 200, in) != NULL;
        }}
    fclose(in);fclose(out);
    return 0;}
//___________________________________________________________________________________________________//
