/*
	Name: Projet 01 multimedia
	Copyright: 
	Author: Rayane
	Date: 17/01/19 13:17
	Description: Mission 01
*/
#include<stdio.h>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include<string.h>
#include<math.h>

void mission1(){
	static const char filename[] = "Equipe_06_Mission1_in.txt";
   FILE *file1 = fopen ( filename, "r" );
   static const char filename2[] = "Equipe_06_Mission1_out.txt";
   FILE *file2 = fopen ( filename2, "a" );
   
   if ( file1 == NULL ){
   	printf("\n Fichier 'Equipe_06_Mission1_in.txt' introvable ! ");
   }else{
   	// recopier le contenu du fichier dans un tableau d'entier pour faciliter l'accees aux inputs
   		char line [255];
   		int tab[6];int i=0;
   		while ((fgets ( line, sizeof line, file1 ) != NULL )) /* lire le fichier ligne par ligne tant qu'il n'est pas vide */
      { 
      	int val= atoi(line);
      	tab[i]=val;
      	i++;
      }
      /* le contenu du tableau selon les indices des cases:
	i0 =====> Niveau de gris NB_Profondeur
	i1 =====> Resolution N
	i2 =====> Resolution M
	i3 =====> Frequance FPS
	i4 =====> Duree
	i5 =====> Limitation de quantification NB_Bit

*/

      //  Calculer les outputs
	
	// =================== Nombre de bits pour repr�senter l�image (en bits) =========================
	
	int NB_Profondeur= tab[0];
	int nbrBit= (int)log2(NB_Profondeur);
	float tmp= nbrBit-log2(NB_Profondeur);
	if ((tmp) < 0) nbrBit=nbrBit+1;
	fprintf(file2,"%i\n",nbrBit);
	
	// =================== Taille de l�image en niveau de gris =========================
	int N=tab[1]; int M=tab[2];
	float Taille_gris =(N *M);
	Taille_gris =Taille_gris/(1024*1024);
	fprintf(file2,"%.2f\n",Taille_gris);
	
	// =================== Taille de l�image couleur =========================
	
	float Taille_couleur=Taille_gris*3;
	fprintf(file2,"%.2f\n",Taille_couleur);
	
	// =================== Taille de la vid�o =========================
	
	float Taille_video= (Taille_couleur*(tab[3]*60)*tab[4])/1024; // frequence*60 pour obtenir la frequence des images par minute
	fprintf(file2,"%.2f\n",Taille_video);
	
	// =================== Quantification intervalle =========================
	int d;
	float q=(int)tab[0]/tab[5];
	for(i=0;i+q<(tab[0]+q);i++){
		d=i+q;
		if (d>tab[0]) d=tab[0];
		
		fprintf(file2," %i -> %i \n",i,d);
		i=i+q;
	}
   		
   }
   fclose ( file1 );
   fclose ( file2 );
}
int main(){
	mission1();
	return 0;
}
